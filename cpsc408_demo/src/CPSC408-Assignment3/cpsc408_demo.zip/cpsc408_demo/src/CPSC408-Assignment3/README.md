# CPSC408-Assignment3

sources:
http://www.sqlitetutorial.net/sqlite-java/insert/ 