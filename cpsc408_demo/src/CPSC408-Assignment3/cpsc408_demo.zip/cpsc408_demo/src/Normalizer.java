import java.sql.*;
import java.util.List;

public class Normalizer {
    private Connection conn;
    private List<List<String>> data;

    public void DatabaseNormalizer(Connection conn, List<List<String>> data) {
        this.conn = conn;
        this.data = data;
    }



}
